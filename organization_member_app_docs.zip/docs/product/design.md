# Product Design Specification

## 1. Design Goal

Create a clean, trustworthy, easy-to-use mobile experience for organization members and a practical management interface for Admin/Manager.

The app is a financial transparency and contribution-tracking tool, not a banking app.

## 2. Visual Direction

Recommended visual character:

- clean white surfaces
- deep green primary color
- warm gold accent
- soft neutral background
- rounded cards
- readable financial numbers
- clear status chips
- restrained icon usage

Suggested palette:

- Primary Green: `#1B5E20`
- Dark Green: `#0F3D2E`
- Gold Accent: `#C9A227`
- Background: `#F5F7F5`
- Surface: `#FFFFFF`
- Success: `#2E7D32`
- Warning: `#F9A825`
- Error: `#C62828`
- Information: `#1565C0`

Typography recommendation:

- Bangla: Noto Sans Bengali or Hind Siliguri
- English: Inter or Noto Sans

## 3. Bilingual UX

Language switch must be accessible from:

- first launch
- login
- profile/settings

Rules:

- do not mix Bangla and English labels on the same screen unless intentionally showing language choice
- financial numbers may remain Arabic numerals initially for consistency unless product later decides otherwise
- dates must use one predictable format per locale
- translated labels should fit without clipping

## 4. Member Navigation

Bottom navigation:

1. Home
2. History
3. Members
4. Messages
5. Profile

Header:

- current screen title
- notification icon where appropriate

## 5. Member Home Layout

Recommended order:

### Header

- member photo/avatar
- greeting
- member name
- member ID

### Current Contribution Card

- monthly required amount
- current month
- status
- paid amount
- remaining amount

### Personal Summary Cards

- total contribution paid
- total donation
- outstanding
- paid months

### Organization Summary

- total income
- total expense
- current balance

### Recent Activity

- latest payment
- latest donation
- latest notification

Do not overload the first screen with full history.

## 6. Status Design

Statuses must include icon/text label.

Suggested visual intent:

- Paid — positive/success
- Partially Paid — warning
- Unpaid — neutral/attention
- Overdue — error
- Paid in Advance — information
- Waived — neutral
- Adjusted — information
- Cancelled — muted/error

Do not communicate status using color alone.

## 7. Contribution History Screen

Controls:

- year selector
- status filter
- optional month filter

Each row/card:

- month
- required
- paid
- remaining
- donation
- status

Tap opens details.

## 8. Payment Details Screen

Show:

- receipt/reference number
- payment date
- total received
- contribution allocation
- donation allocation
- months covered
- payment method
- recorded by
- approval status if applicable
- note

## 9. All Members Screen

Purpose: transparency, not account administration.

Member-facing list should show only fields permitted by Admin visibility settings.

Filters:

- member/name if visible
- month
- year
- status

Avoid exposing private phone numbers or profile details.

## 10. Organization Finance Screen

Top summary cards:

- total income
- total expenses
- current balance
- total donations

Then show:

- monthly totals
- recent public financial entries
- expense categories if permitted

Do not make this screen look like double-entry accounting software.

## 11. Notifications

Each notification item:

- title
- short message
- timestamp
- unread indicator
- optional related record link

Actions:

- mark read
- mark all read

## 12. Messaging

Keep simple:

- conversations list
- text message thread
- compose field
- send button

No complex social/chat UI.

## 13. Member Profile

Sections:

- identity
- contact
- membership
- contribution information
- account settings

Editable fields must be visually distinct from read-only financial/system fields.

## 14. Admin Dashboard

Desktop/tablet responsive dashboard should prioritize:

- member count
- expected monthly contribution
- collected amount
- outstanding
- donations
- income
- expenses
- balance

Quick actions:

- Add Member
- Record Payment
- Add Donation
- Add Expense
- Send Message

## 15. Admin Member List

Table/list columns:

- member
- member ID
- mobile
- monthly contribution
- current-month status
- outstanding
- account status
- actions

Search/filter area should remain visible and simple.

## 16. Add/Edit Member Form

Group fields into sections:

1. Basic Information
2. Contact Information
3. Membership Information
4. Contribution Setup
5. Account Credentials
6. Notes/Status

For small screens use a full-screen form.

For larger screens use a large modal or dedicated page.

Form requirements:

- scrollable content
- sticky header if useful
- visible Save/Cancel actions
- validation messages near fields
- confirm before discarding unsaved changes

## 17. Record Payment UX

This is the most important Admin flow.

Recommended structure:

### Step 1 — Select Member

Show:

- member name
- member ID
- monthly contribution
- outstanding

### Step 2 — Enter Received Amount

Fields:

- date
- total received
- payment method
- optional reference

### Step 3 — Allocate

Controls:

- select one or multiple months
- show required amount for each month
- enter/apply contribution allocation
- show remaining due
- show unallocated amount
- allow remaining amount to be assigned as donation

### Step 4 — Review

Show calculation summary before save:

- total received
- contribution total
- donation total
- months covered
- remaining due

### Step 5 — Confirm

Require explicit confirmation.

## 18. Partial Payment UX

If received amount is less than selected month requirement:

- clearly label `Partially Paid`
- show paid amount
- show remaining due
- do not mark month as fully paid

## 19. Multi-Month UX

Admin can select multiple months.

The interface should show:

- month
- required
- allocated
- remaining

Total allocation must not exceed total received unless the product later supports credit/adjustment.

## 20. Extra Donation UX

If payment has unallocated remainder:

Prompt:

`৳500 remains after contribution allocation. Add this amount as donation?`

Actions:

- Add as Donation
- Adjust Allocation

Do not silently convert unexplained remainder into donation.

## 21. Admin Income/Expense UX

Simple financial form:

- category
- amount
- date
- source/receiver
- method
- note
- visibility

Confirmation required before save.

## 22. Empty, Loading, and Error States

Every major list must have:

- loading state
- meaningful empty state
- retry/error state

Avoid raw messages such as `No Data Found` when a friendlier explanation is possible.

Example:

`No payment records are available for the selected period.`

## 23. Confirmation Dialogs

Required for:

- deactivate member
- reset password
- approve payment
- cancel payment
- delete/cancel donation
- delete/cancel expense
- discard unsaved form changes

## 24. Accessibility and Usability

- large touch targets
- readable 16px+ body text equivalent
- sufficient contrast
- no critical information communicated by color only
- avoid dense financial tables on small screens
- use cards or stacked rows on phones

## 25. Prototype Required States

Include dummy data for:

- paid member
- unpaid member
- partially paid member
- advance-paid member
- member with donation
- member with multiple months paid
- member with outstanding amount
- active and inactive accounts
- notifications
- messages
- income entries
- expense entries
