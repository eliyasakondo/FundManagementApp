# Confirmed Product Decisions

## D-001 — Product Type

The system is an organization member contribution and donation management system.

It is not an educational-institute or student fee application.

## D-002 — Member Count

The organization has 200+ members.

The UI should support search/filter and not assume a tiny member list.

## D-003 — Roles

Initial roles:

- Admin
- Manager
- Member

No Student or Guardian role.

## D-004 — Account Creation

Members cannot self-register.

Admin creates the member account and provides initial login credentials.

Member may change the password after login.

## D-005 — Payment Submission

Members do not submit payment inside the application in the initial version.

Money is paid outside the app.

Admin or Manager records the payment.

## D-006 — Payment Approval

Admin and Manager may approve/confirm payments according to permissions.

## D-007 — Monthly Contribution

Each member may have a different fixed monthly contribution amount.

Admin sets this amount.

## D-008 — Contribution Changes

Contribution amount may change later.

Historical months must retain the previous rate.

Use an effective date/month concept.

## D-009 — Overpayment

If received amount exceeds selected contribution obligation, extra amount may be allocated as donation.

This allocation must be explicit.

## D-010 — Partial Payment

Partial monthly payments are supported.

A month remains `Partially Paid` until the required contribution is fulfilled or otherwise adjusted/waived.

## D-011 — Multi-Month Payment

Admin/Manager may record one payment against multiple months.

## D-012 — Advance Payment

Admin/Manager may allocate payment to future months.

## D-013 — Member Visibility

Members can view all-member payment/contribution history.

The Admin controls which fields are visible.

## D-014 — Donation Visibility

Donation visibility is configurable by Admin.

Possible output includes named, amount-only, anonymous, or private records.

## D-015 — Organization Financial Transparency

Members may view organization total income, total expenses, and available balance according to configured visibility.

## D-016 — Member Editing

Members may edit only allowed personal information.

They cannot edit contribution amount, financial history, role, or account status.

## D-017 — Admin Access

Admin has access to all member details and financial records.

## D-018 — Notifications

After a payment is successfully recorded/approved, the member should see an in-app notification.

## D-019 — Messaging

A basic messaging option is required between members and Admin/Manager.

Advanced real-time chat is not required.

## D-020 — Languages

Bangla and English are required.

Language can be changed inside the app.

## D-021 — Technical Architecture

No final technology architecture is decided in these product documents.

Technical decisions should be made after reviewing the Android Studio project and discussing them with the coding agent.
