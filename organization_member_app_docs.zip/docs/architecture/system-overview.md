# System Overview — Technology Agnostic

## 1. Scope of This Document

This document describes logical modules and data relationships only.

It intentionally does not decide:

- Android framework architecture
- backend framework
- database engine
- networking library
- dependency injection
- local storage
- cloud provider
- notification provider

Those choices should be made after inspecting the actual project.

## 2. Logical System Areas

### Identity and Access

Responsibilities:

- Admin login
- Manager login
- Member login
- password management
- role/permission enforcement
- account status

### Member Management

Responsibilities:

- member profile
- membership details
- account linkage
- monthly contribution configuration
- active/inactive status

### Contribution Management

Responsibilities:

- monthly expected amount
- effective contribution rate
- month status
- outstanding calculation
- waiver/adjustment

### Payment Management

Responsibilities:

- received payment record
- payment method/reference
- allocation to one/multiple months
- partial/advance handling
- approval/cancellation

### Donation Management

Responsibilities:

- extra donation allocation
- direct donation
- anonymous/external donation
- visibility settings

### Finance Management

Responsibilities:

- income records
- expense records
- organization totals
- current balance
- reports

### Notification Management

Responsibilities:

- payment confirmation
- contribution changes
- announcements
- unread/read state

### Messaging

Responsibilities:

- member/admin conversations
- member/manager conversations
- optional broadcast

### Reporting

Responsibilities:

- collection summary
- outstanding members
- member statement
- donation
- income
- expense
- balance

## 3. Conceptual Data Entities

### UserAccount

Suggested concepts:

- id
- role
- login identifier
- password hash/credential reference
- status
- must_change_password
- last_login_at

### Member

- id
- member_id
- user_account_id
- Bangla name
- English name
- contact fields
- membership fields
- status

### ContributionRate

- id
- member_id
- amount
- effective_from
- effective_to or open-ended state
- created_by

Purpose: preserve contribution history.

### ContributionPeriod

Represents a member's obligation for a month.

Suggested concepts:

- member_id
- year
- month
- required_amount
- paid_amount
- waived_amount
- remaining_amount
- status

This may be persisted or derived depending on technical architecture.

### Payment

- id
- member_id
- received_date
- total_amount
- payment_method
- reference
- status
- note
- recorded_by
- approved_by

### PaymentAllocation

- id
- payment_id
- contribution period/month reference
- amount
- allocation type

Purpose: one payment can cover multiple months.

### Donation

- id
- member_id nullable
- payment_id nullable
- donor type
- amount
- date
- purpose
- visibility
- recorded_by

### Income

Conceptual income record or report projection.

Important: do not double-count contribution/payment/donation when implementing summaries.

### Expense

- id
- category
- amount
- date
- receiver/vendor
- method
- description
- visibility
- recorded_by
- approved_by

### Notification

- id
- recipient
- type
- title
- message
- related record
- read status
- created_at

### MessageThread / Message

Basic conversation entities.

### AuditEvent

Optional/extended:

- actor
- action
- entity
- old/new summary
- timestamp

## 4. Key Relationships

- One Member has one login account in the initial model.
- One Member has many ContributionRates over time.
- One Member has many monthly ContributionPeriods.
- One Member has many Payments.
- One Payment has one or many PaymentAllocations.
- One Payment may create a Donation allocation.
- One Member may have many direct Donations.
- Organization has many Expenses.
- Users receive many Notifications.

## 5. Financial Source of Truth

The implementation should have one clear source of truth for financial totals.

Recommended logical principle:

- contribution totals come from valid contribution allocations
- donation totals come from valid donation records/allocations
- expense totals come from valid expense records
- current balance is derived from valid income minus valid expense

Do not store conflicting duplicated totals unless cache/summary strategy has explicit synchronization rules.

## 6. Permission Boundary

### Member

Read-focused access to own records plus published organization/member information.

### Manager

Operational write access based on configured permissions.

### Admin

Full control.

Permission enforcement must exist at the business/API layer, not only by hiding UI buttons.

## 7. Data Integrity Expectations

- monetary values must use precise decimal handling
- month/year contribution records must not be duplicated incorrectly
- payment total and allocations must reconcile
- cancelled records must not count in totals
- rate changes must preserve historical calculations
- permissions must protect Admin-only fields

## 8. Performance Expectations

200+ members is modest, but lists should still support:

- pagination or incremental loading
- server-side or efficient filtering where applicable
- indexed search fields in final database design

## 9. Offline Behavior

Not yet decided.

If the application supports offline mode later, financial write operations must avoid silent duplicate synchronization.

Mark as a technical decision before implementation.

## 10. Notification Delivery

Product requires in-app notification records.

Push notification technology is a separate technical decision.

The product should still retain notification history even if push delivery fails.
