# Test Plan

## 1. Testing Objective

Verify:

- business-rule correctness
- financial calculation correctness
- role permissions
- bilingual UI behavior
- member/account workflows
- notification behavior

## 2. Authentication Tests

### Member Login

- valid credentials → login succeeds
- invalid password → error shown
- inactive account → access denied
- logout → protected screen cannot be reopened without login

### Password

- temporary password → change-password prompt if enabled
- new password and confirmation mismatch → validation error
- successful password change → old password no longer works

## 3. Role Permission Tests

### Member

Verify Member cannot:

- add member
- change contribution amount
- record payment
- approve payment
- edit income
- edit expense

### Manager

Verify access follows configured permission.

### Admin

Verify full expected access.

## 4. Member Management Tests

- create member with required fields
- duplicate member ID rejected
- edit member
- deactivate member
- reactivate member
- search by name
- search by member ID
- search by mobile
- filters return expected records

## 5. Contribution Rate Tests

### New Member

Set ৳1,000/month.

Verify applicable month requirement = ৳1,000.

### Rate Change

Jan–Jun = ৳500  
Jul onward = ৳1,000

Verify:

- January remains ৳500
- June remains ৳500
- July = ৳1,000
- future applicable months = ৳1,000

## 6. Full Payment Test

Monthly = ৳1,000  
Received = ৳1,000

Expected:

- contribution = ৳1,000
- donation = ৳0
- remaining = ৳0
- status = Paid

## 7. Extra Amount Test

Monthly = ৳1,000  
Received = ৳1,500

Allocate:

- contribution = ৳1,000
- donation = ৳500

Expected:

- month = Paid
- donation total increases ৳500
- organization total income increases by ৳1,500 exactly once

## 8. Partial Payment Test

Monthly = ৳1,000  
Received = ৳600

Expected:

- paid = ৳600
- remaining = ৳400
- status = Partially Paid

Add later payment = ৳400

Expected:

- cumulative paid = ৳1,000
- remaining = ৳0
- status = Paid

## 9. Multiple Partial Payments

Payments:

- ৳300
- ৳400
- ৳300

Expected final month status = Paid.

## 10. Multi-Month Payment Test

Monthly = ৳1,000  
Received = ৳3,000

Allocate Jan–Mar.

Expected:

- Jan Paid
- Feb Paid
- Mar Paid
- donation = 0

## 11. Multi-Month + Donation

Received = ৳3,500

Allocate:

- Jan = ৳1,000
- Feb = ৳1,000
- Mar = ৳1,000
- Donation = ৳500

Expected totals must reconcile to ৳3,500.

## 12. Advance Payment Test

Pay future months.

Expected:

- future month records show Paid in Advance
- contribution totals include valid payment
- no donation unless explicitly allocated

## 13. Underfunded Multi-Month Test

Select Jan + Feb  
Total required = ৳2,000  
Received = ৳1,500

Allocate:

- Jan = ৳1,000
- Feb = ৳500

Expected:

- Jan = Paid
- Feb = Partially Paid
- Feb remaining = ৳500

## 14. Allocation Validation Tests

Reject or prevent:

- negative allocation
- contribution allocation greater than received amount
- donation allocation causing total allocation > received
- zero-value payment
- missing member
- invalid month reference

## 15. Cancel Payment Test

Create valid payment and confirm totals.

Cancel it.

Expected:

- member contribution recalculated
- donation recalculated
- organization income recalculated
- affected month status recalculated
- cancelled record excluded from active totals

## 16. Waiver Test

Monthly = ৳1,000  
Waive = ৳1,000

Expected:

- outstanding = 0
- cash income does not increase
- waiver record remains visible to Admin

## 17. Income and Expense Test

Income = ৳10,000  
Expense = ৳4,000

Expected current balance = ৳6,000.

Add expense ৳1,000.

Expected current balance = ৳5,000.

## 18. No Double-Counting Test

Record payment:

- contribution ৳1,000
- donation ৳500

Expected organization income impact = ৳1,500, not ৳3,000.

## 19. Member Dashboard Tests

Verify member sees:

- correct monthly amount
- correct current status
- correct outstanding
- correct contribution total
- correct donation total

## 20. All-Member Visibility Tests

Test Admin settings:

### Name + Amount

Member sees both.

### Name Hidden

Member does not see donor/member identity.

### Amount Hidden

Member does not see amount.

### Private

Record not visible to normal Member.

## 21. Notification Tests

After valid payment:

- notification created
- correct member receives it
- message contains correct amount/month
- unread count increments
- mark read works

## 22. Messaging Tests

- member sends message to Admin
- Admin sees message
- Admin replies
- member sees reply
- unauthorized member cannot read another member's conversation

## 23. Language Tests

For Bangla and English:

- login labels
- dashboard labels
- statuses
- forms
- validation errors
- notifications
- menu labels

Verify no clipped text on common phone widths.

## 24. 200+ Member Tests

Seed at least 200 members.

Verify:

- member list opens acceptably
- search is responsive
- filter is responsive
- pagination/incremental loading works if implemented

## 25. Error-State Tests

Simulate:

- network/server error
- expired session
- save failure
- empty history
- no notifications

Verify useful user-facing message and retry path.

## 26. Acceptance Test Checklist

- [ ] Admin can create member account
- [ ] Member can log in
- [ ] Member can change password
- [ ] Admin can set monthly contribution
- [ ] Contribution history preserves old rate
- [ ] Full payment works
- [ ] Partial payment works
- [ ] Multi-month payment works
- [ ] Advance payment works
- [ ] Extra donation allocation works
- [ ] Cancelled record is excluded from totals
- [ ] Income/expense balance is correct
- [ ] Member sees personal history
- [ ] Member sees permitted all-member history
- [ ] Notification is generated after payment
- [ ] Basic messaging works
- [ ] Member cannot access Admin financial actions
- [ ] Bangla core UI works
- [ ] English core UI works
