# Development Task Plan

## Goal

Implement the product incrementally so financial rules are correct before secondary features are added.

## Phase 0 — Project Review

- inspect existing Android Studio project
- identify current modules and build setup
- identify whether backend already exists
- decide technical architecture separately
- map product docs to implementation plan

Deliverable:

- confirmed technical plan
- no business-rule changes

## Phase 1 — Core Identity and Member Foundation

### Authentication

- Admin login
- Manager login
- Member login
- logout
- password change
- temporary-password state
- account active/inactive

### Member Management

- member list
- member search
- add member
- edit member
- view member
- activate/deactivate member
- member profile screen

### Acceptance

- Admin can create member credentials
- Member can log in
- inactive member cannot use protected app areas

## Phase 2 — Contribution Setup

- per-member monthly contribution
- effective month/date
- contribution history
- monthly requirement calculation
- unpaid/paid/partial status foundation

### Acceptance

- changing current contribution does not alter historical month requirements

## Phase 3 — Payment Engine

Implement before dashboard polish.

- record payment
- payment method
- reference
- single-month allocation
- multi-month allocation
- partial allocation
- advance allocation
- donation remainder allocation
- payment review screen
- validation

### Acceptance

- payment allocation reconciles with total received
- month statuses calculate correctly

## Phase 4 — Payment Approval and Corrections

- approval state if enabled
- recorded by
- approved by
- cancel payment
- adjustment behavior
- recalculation after correction

### Acceptance

- cancelled payment no longer affects totals

## Phase 5 — Donation

- extra donation from payment
- direct member donation
- optional anonymous/external donation depending scope
- donation visibility
- member donation total
- organization donation total

## Phase 6 — Income and Expense

- income categories
- other income
- expense categories
- expense entry
- expense visibility
- organization totals
- current balance

Critical test:

- no double-counting between Payment, Contribution, Donation, and Income summaries

## Phase 7 — Member App Dashboard

- profile header
- current month contribution
- personal totals
- organization summary
- recent activity
- contribution history
- payment history
- donation history
- all-member history

## Phase 8 — Notifications

- notification storage
- payment confirmation notification
- contribution-change notification
- mark read
- notification list

Push delivery may be added based on technical decision.

## Phase 9 — Messaging

- conversation list
- Member → Admin/Manager message
- Admin/Manager reply
- message notification
- optional broadcast based on scope

## Phase 10 — Admin Dashboard and Reports

- summary cards
- recent payments
- recent donations
- recent expenses
- unpaid members
- partial payments
- monthly collection report
- member statement
- donation report
- income report
- expense report
- balance report

## Phase 11 — Bilingual Completion

- replace remaining hardcoded user-facing text
- verify Bangla layout
- verify long labels
- verify financial/date formatting

## Phase 12 — Testing and Hardening

- execute `test_plan.md`
- permission testing
- financial calculation regression
- empty/loading/error states
- invalid input testing
- cancellation/adjustment testing
- 200+ member list performance test

## Phase 13 — Delivery

- production configuration
- initial Admin account
- deployment/build
- smoke test
- handover notes

## Priority Levels

### P0 — Must Have

- authentication
- member management
- monthly contribution setup
- payment engine
- partial payment
- multi-month payment
- donation allocation
- member dashboard/history
- income/expense summary
- bilingual core UI

### P1 — Important

- notifications
- messaging
- all-member history
- search/filter
- payment approval
- reports

### P2 — Optional/Extended

- anonymous/external donation
- advanced exports
- configurable Manager permissions
- detailed audit log
- advanced visibility rules
